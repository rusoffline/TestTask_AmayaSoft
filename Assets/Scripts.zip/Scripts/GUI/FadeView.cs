using UnityEngine;
using DG.Tweening;

public class FadeView : FadeableBase
{
}
