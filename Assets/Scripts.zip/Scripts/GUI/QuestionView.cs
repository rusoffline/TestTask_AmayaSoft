using TMPro;
using UnityEngine;

public class QuestionView : FadeableBase
{
    [SerializeField]
    private TMP_Text questionText;

    public void UpdateQest(CardData card)
    {
        questionText.text = $"Find {card.Identifier.ToUpper()}";
    }
}
