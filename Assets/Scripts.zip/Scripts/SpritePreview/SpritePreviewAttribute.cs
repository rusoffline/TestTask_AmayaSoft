using UnityEngine;

public class SpritePreviewAttribute : PropertyAttribute
{
}
